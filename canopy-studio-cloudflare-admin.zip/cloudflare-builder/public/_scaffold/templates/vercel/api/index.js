import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import { neon } from '@neondatabase/serverless';
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

const app = express();
const SITE_ID = '__SITE_ID__';
const DEFAULT_CONFIG = __SITE_CONFIG_JSON__;
const SLOT_TIMES = ['09:00','09:30','10:00','10:30','11:00','11:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30'];
const MAX_BODY = '20kb';

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'], fontSrc: ["'self'", 'data:'], connectSrc: ["'self'"],
      objectSrc: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], frameAncestors: ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null
    }
  },
  crossOriginResourcePolicy: { policy: 'same-site' }
}));
app.use(express.json({ limit: MAX_BODY, strict: true }));

const getDb = () => {
  if (!process.env.DATABASE_URL) throw new Error('Database is not configured.');
  return neon(process.env.DATABASE_URL);
};
const csrfSecret = () => process.env.CSRF_SECRET || process.env.ADMIN_API_KEY || (process.env.NODE_ENV === 'production' ? '' : 'local-development-only-change-before-deploy');
const csrfCookie = 'practice_csrf';
const b64url = (value) => Buffer.from(value).toString('base64url');
function makeCsrfToken() {
  const nonce = b64url(randomBytes(24));
  const secret = csrfSecret();
  if (!secret) throw new Error('CSRF_SECRET is not configured.');
  const signature = createHmac('sha256', secret).update(nonce).digest('base64url');
  return `${nonce}.${signature}`;
}
function tokenIsValid(token) {
  const secret = csrfSecret();
  if (!secret || typeof token !== 'string') return false;
  const [nonce, signature, ...rest] = token.split('.');
  if (!nonce || !signature || rest.length) return false;
  const expected = createHmac('sha256', secret).update(nonce).digest();
  let actual;
  try { actual = Buffer.from(signature, 'base64url'); } catch (_) { return false; }
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
function cookieValue(header, name) {
  for (const item of String(header || '').split(';')) {
    const separator = item.indexOf('=');
    if (separator < 0) continue;
    if (item.slice(0, separator).trim() === name) return decodeURIComponent(item.slice(separator + 1).trim());
  }
  return '';
}
function csrfGuard(req, res, next) {
  const cookie = cookieValue(req.headers.cookie, csrfCookie);
  const header = req.get('x-csrf-token');
  const origin = req.get('origin');
  const expectedOrigin = `${req.protocol}://${req.get('host')}`;
  if (origin && origin !== expectedOrigin) return res.status(403).json({ error: 'Cross-site request rejected.' });
  if (!cookie || !header || cookie !== header || !tokenIsValid(header)) return res.status(403).json({ error: 'Your security token expired. Refresh and try again.' });
  next();
}
function adminGuard(req, res, next) {
  const expected = process.env.ADMIN_API_KEY || '';
  const given = String(req.get('authorization') || '').replace(/^Bearer\s+/i, '');
  if (!expected) return res.status(503).json({ error: 'Owner access has not been configured. Set ADMIN_API_KEY.' });
  const left = Buffer.from(expected); const right = Buffer.from(given);
  if (left.length !== right.length || !timingSafeEqual(left, right)) return res.status(401).json({ error: 'Owner key is not valid.' });
  next();
}
function cleanText(value, max, fallback = '') {
  return String(value ?? fallback).trim().slice(0, max);
}
function color(value, fallback) { return /^#[0-9a-f]{6}$/i.test(String(value || '')) ? String(value) : fallback; }
function cleanSiteConfig(input = {}) {
  const merged = { ...DEFAULT_CONFIG, ...input };
  return {
    ...DEFAULT_CONFIG,
    businessName: cleanText(merged.businessName, 80, DEFAULT_CONFIG.businessName),
    brandName: cleanText(merged.brandName, 80, DEFAULT_CONFIG.brandName),
    location: cleanText(merged.location, 100, DEFAULT_CONFIG.location),
    email: cleanText(merged.email, 120, DEFAULT_CONFIG.email),
    phone: cleanText(merged.phone, 30, DEFAULT_CONFIG.phone),
    primaryColor: color(merged.primaryColor, DEFAULT_CONFIG.primaryColor),
    accentColor: color(merged.accentColor, DEFAULT_CONFIG.accentColor),
      paperColor: color(merged.paperColor, DEFAULT_CONFIG.paperColor),
    fontStyle: merged.fontStyle === 'sans' ? 'sans' : 'serif',
    theme: ['canopy','clay','coastal','editorial','neat','launcher','air'].includes(merged.theme) ? merged.theme : DEFAULT_CONFIG.theme,
    editorialAccent: ['black','teal','forest'].includes(merged.editorialAccent) ? merged.editorialAccent : 'black',
    features: { ...DEFAULT_CONFIG.features, ...(merged.features || {}), gallery: merged.features?.gallery !== false }
  };
}
function validDate(value) { return /^\d{4}-\d{2}-\d{2}$/.test(value) && value >= new Date().toISOString().slice(0, 10); }
function slugify(value) { return String(value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 160) || 'practice-note'; }
function cleanGalleryImage(value) {
  const raw = cleanText(value, 2048);
  if (!raw) return '';
  if (raw.startsWith('/') && !raw.startsWith('//')) return raw;
  try { const url = new URL(raw); return url.protocol === 'https:' ? url.href : null; } catch (_) { return null; }
}
function galleryPayload(value = {}) {
  const imageUrl = cleanGalleryImage(value.imageUrl);
  const sortOrder = Number(value.sortOrder ?? 0);
  return {
    title: cleanText(value.title, 120), imageUrl, altText: cleanText(value.altText, 180),
    caption: cleanText(value.caption, 300), category: cleanText(value.category, 60, 'Practice life') || 'Practice life',
    status: value.status === 'published' ? 'published' : 'draft', sortOrder
  };
}
function validGalleryPayload(item) {
  return item.title && item.imageUrl !== null && Number.isInteger(item.sortOrder) && item.sortOrder >= 0 && item.sortOrder <= 9999 && (!item.imageUrl || item.altText);
}
function asyncRoute(handler) { return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next); }

app.get('/api/health', (_req, res) => res.json({ ok: true, runtime: 'vercel-node', siteId: SITE_ID }));
app.get('/api/csrf', (req, res) => {
  try {
    const token = makeCsrfToken();
    const secure = req.secure ? '; Secure' : '';
    res.setHeader('Set-Cookie', `${csrfCookie}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=3600${secure}`);
    res.json({ token });
  } catch (error) { res.status(503).json({ error: error.message }); }
});
app.get('/api/site', asyncRoute(async (_req, res) => {
  if (!process.env.DATABASE_URL) return res.json({ config: DEFAULT_CONFIG, source: 'generated-fallback' });
  try {
    const sql = getDb();
    const rows = await sql`SELECT config FROM sites WHERE site_id = ${SITE_ID} LIMIT 1`;
    res.json({ config: rows[0]?.config || DEFAULT_CONFIG, source: rows[0] ? 'neon' : 'generated-fallback' });
  } catch (error) { console.error('site config read failed', error); res.json({ config: DEFAULT_CONFIG, source: 'generated-fallback' }); }
}));
app.get('/api/posts', asyncRoute(async (_req, res) => {
  if (!DEFAULT_CONFIG.features?.blog) return res.json({ posts: [] });
  if (!process.env.DATABASE_URL) return res.json({ posts: DEFAULT_CONFIG.demoPosts || [] });
  const sql = getDb();
  const rows = await sql`SELECT id, title, slug, excerpt, body, category, published_at AS "publishedAt", created_at AS "createdAt" FROM blog_posts WHERE site_id = ${SITE_ID} AND status = 'published' ORDER BY published_at DESC NULLS LAST, created_at DESC LIMIT 12`;
  res.json({ posts: rows });
}));
app.get('/api/gallery', asyncRoute(async (_req, res) => {
  if (!DEFAULT_CONFIG.features?.gallery) return res.json({ items: [] });
  if (!process.env.DATABASE_URL) return res.json({ items: DEFAULT_CONFIG.demoGallery || [] });
  const sql = getDb();
  const rows = await sql`SELECT id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt" FROM gallery_items WHERE site_id = ${SITE_ID} AND status = 'published' ORDER BY sort_order ASC, created_at DESC LIMIT 24`;
  res.json({ items: rows });
}));
app.get('/api/availability', asyncRoute(async (req, res) => {
  const date = String(req.query.date || '');
  if (!validDate(date)) return res.status(400).json({ error: 'Choose a valid future date.' });
  const weekday = new Date(`${date}T00:00:00Z`).getUTCDay();
  if (weekday === 0) return res.json({ slots: [] });
  if (!process.env.DATABASE_URL) return res.status(503).json({ error: 'Appointment database is not configured.' });
  const sql = getDb();
  const takenRows = await sql`SELECT to_char(appointment_time, 'HH24:MI') AS time FROM appointments WHERE site_id = ${SITE_ID} AND appointment_date = ${date}::date AND status <> 'cancelled'`;
  const taken = new Set(takenRows.map((row) => row.time));
  res.json({ slots: SLOT_TIMES.filter((time) => !taken.has(time)).map((time) => ({ time, label: displayTime(time) })) });
}));
function displayTime(value) {
  const [hour, minute] = value.split(':').map(Number); const suffix = hour >= 12 ? 'pm' : 'am'; const shown = hour % 12 || 12;
  return `${shown}:${String(minute).padStart(2, '0')} ${suffix}`;
}
app.post('/api/appointments', csrfGuard, asyncRoute(async (req, res) => {
  if (!DEFAULT_CONFIG.features?.scheduling) return res.status(404).json({ error: 'Online appointment requests are not enabled.' });
  const value = req.body || {};
  const booking = {
    name: cleanText(value.name, 100), email: cleanText(value.email, 120), phone: cleanText(value.phone, 30),
    service: cleanText(value.service, 120), date: String(value.date || ''), time: String(value.time || ''), context: cleanText(value.context, 100)
  };
  if (!booking.name || !/^\S+@\S+\.\S+$/.test(booking.email) || !booking.phone || !DEFAULT_CONFIG.services.includes(booking.service) || !validDate(booking.date) || !SLOT_TIMES.includes(booking.time)) return res.status(400).json({ error: 'Check the required appointment details and choose a valid time.' });
  try {
    const sql = getDb();
    const rows = await sql`INSERT INTO appointments (site_id, name, email, phone, service, appointment_date, appointment_time, context) VALUES (${SITE_ID}, ${booking.name}, ${booking.email}, ${booking.phone}, ${booking.service}, ${booking.date}::date, ${booking.time}::time, ${booking.context}) RETURNING id`;
    res.status(201).json({ ok: true, id: rows[0]?.id });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'That time was just taken. Please choose another available time.' });
    console.error('appointment request failed', error);
    res.status(503).json({ error: 'We could not save your request. Please call the practice.' });
  }
}));
app.get('/api/admin/posts', adminGuard, asyncRoute(async (_req, res) => {
  const sql = getDb();
  const rows = await sql`SELECT id, title, slug, excerpt, body, category, status, published_at AS "publishedAt", created_at AS "createdAt" FROM blog_posts WHERE site_id = ${SITE_ID} ORDER BY created_at DESC LIMIT 100`;
  res.json({ posts: rows });
}));
app.post('/api/admin/posts', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const value = req.body || {};
  const title = cleanText(value.title, 140); const slug = slugify(value.slug || title);
  const excerpt = cleanText(value.excerpt, 260); const body = cleanText(value.body, 12000);
  const category = cleanText(value.category, 60, 'Practice notes') || 'Practice notes';
  const status = value.status === 'published' ? 'published' : 'draft';
  if (!title || !body) return res.status(400).json({ error: 'A title and article body are required.' });
  try {
    const sql = getDb();
    const rows = await sql`INSERT INTO blog_posts (site_id, title, slug, excerpt, body, category, status, published_at) VALUES (${SITE_ID}, ${title}, ${slug}, ${excerpt}, ${body}, ${category}, ${status}, CASE WHEN ${status} = 'published' THEN now() ELSE NULL END) RETURNING id, title, slug, excerpt, body, category, status, created_at AS "createdAt"`;
    res.status(201).json({ post: rows[0] });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'That URL slug is already in use.' });
    throw error;
  }
}));
app.put('/api/admin/posts/:id', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const id = String(req.params.id || ''); const value = req.body || {};
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ error: 'Invalid post id.' });
  const title = cleanText(value.title, 140); const slug = slugify(value.slug || title);
  const excerpt = cleanText(value.excerpt, 260); const body = cleanText(value.body, 12000);
  const category = cleanText(value.category, 60, 'Practice notes') || 'Practice notes';
  const status = value.status === 'published' ? 'published' : 'draft';
  if (!title || !body) return res.status(400).json({ error: 'A title and article body are required.' });
  try {
    const sql = getDb();
    const rows = await sql`UPDATE blog_posts SET title = ${title}, slug = ${slug}, excerpt = ${excerpt}, body = ${body}, category = ${category}, status = ${status}, published_at = CASE WHEN ${status} = 'published' THEN COALESCE(published_at, now()) ELSE NULL END, updated_at = now() WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id, title, slug, excerpt, body, category, status, published_at AS "publishedAt"`;
    if (!rows.length) return res.status(404).json({ error: 'That post was not found.' });
    res.json({ post: rows[0] });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'That URL slug is already in use.' });
    throw error;
  }
}));
app.delete('/api/admin/posts/:id', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const id = String(req.params.id || '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ error: 'Invalid post id.' });
  const sql = getDb();
  const rows = await sql`DELETE FROM blog_posts WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id`;
  if (!rows.length) return res.status(404).json({ error: 'That post was not found.' });
  res.json({ ok: true });
}));
app.get('/api/admin/gallery', adminGuard, asyncRoute(async (_req, res) => {
  const sql = getDb();
  const rows = await sql`SELECT id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt" FROM gallery_items WHERE site_id = ${SITE_ID} ORDER BY sort_order ASC, created_at DESC LIMIT 100`;
  res.json({ items: rows });
}));
app.post('/api/admin/gallery', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const item = galleryPayload(req.body || {});
  if (!validGalleryPayload(item)) return res.status(400).json({ error: 'Add a title, valid HTTPS or same-site image URL and alternative text. Display order must be from 0 to 9999.' });
  const sql = getDb();
  const rows = await sql`INSERT INTO gallery_items (site_id, title, image_url, alt_text, caption, category, status, sort_order) VALUES (${SITE_ID}, ${item.title}, ${item.imageUrl}, ${item.altText}, ${item.caption}, ${item.category}, ${item.status}, ${item.sortOrder}) RETURNING id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt"`;
  res.status(201).json({ item: rows[0] });
}));
app.put('/api/admin/gallery/:id', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const id = String(req.params.id || '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ error: 'Invalid gallery item id.' });
  const item = galleryPayload(req.body || {});
  if (!validGalleryPayload(item)) return res.status(400).json({ error: 'Add a title, valid HTTPS or same-site image URL and alternative text. Display order must be from 0 to 9999.' });
  const sql = getDb();
  const rows = await sql`UPDATE gallery_items SET title = ${item.title}, image_url = ${item.imageUrl}, alt_text = ${item.altText}, caption = ${item.caption}, category = ${item.category}, status = ${item.status}, sort_order = ${item.sortOrder}, updated_at = now() WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt"`;
  if (!rows.length) return res.status(404).json({ error: 'That gallery item was not found.' });
  res.json({ item: rows[0] });
}));
app.delete('/api/admin/gallery/:id', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const id = String(req.params.id || '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(400).json({ error: 'Invalid gallery item id.' });
  const sql = getDb();
  const rows = await sql`DELETE FROM gallery_items WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id`;
  if (!rows.length) return res.status(404).json({ error: 'That gallery item was not found.' });
  res.json({ ok: true });
}));
app.get('/api/admin/appointments', adminGuard, asyncRoute(async (_req, res) => {
  const sql = getDb();
  const rows = await sql`SELECT id, name, email, phone, service, context, status, appointment_date::text AS date, to_char(appointment_time, 'HH24:MI') AS time FROM appointments WHERE site_id = ${SITE_ID} AND appointment_date >= current_date AND appointment_date <= current_date + interval '90 days' ORDER BY appointment_date ASC, appointment_time ASC LIMIT 200`;
  res.json({ appointments: rows.map((row) => ({ ...row, timeLabel: displayTime(row.time) })) });
}));
app.patch('/api/admin/appointments/:id', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const id = String(req.params.id || '');
  const status = String(req.body?.status || '');
  if (!/^[0-9a-f-]{36}$/i.test(id) || !['requested', 'confirmed', 'cancelled'].includes(status)) return res.status(400).json({ error: 'Invalid appointment update.' });
  try {
    const sql = getDb();
    const rows = await sql`UPDATE appointments SET status = ${status} WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id, status`;
    if (!rows.length) return res.status(404).json({ error: 'That appointment was not found.' });
    res.json({ appointment: rows[0] });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'That time slot has already been taken.' });
    throw error;
  }
}));
app.put('/api/site', csrfGuard, adminGuard, asyncRoute(async (req, res) => {
  const config = cleanSiteConfig(req.body || {});
  if (!config.businessName || (config.email && !/^\S+@\S+\.\S+$/.test(config.email))) return res.status(400).json({ error: 'Check the practice name and contact email.' });
  const sql = getDb();
  const rows = await sql`INSERT INTO sites (site_id, config) VALUES (${SITE_ID}, ${JSON.stringify(config)}::jsonb) ON CONFLICT (site_id) DO UPDATE SET config = EXCLUDED.config, updated_at = now() RETURNING config`;
  res.json({ config: rows[0].config });
}));

app.use('/api', (_req, res) => res.status(404).json({ error: 'API route not found.' }));
app.use((error, _req, res, _next) => {
  console.error('API error', error);
  if (res.headersSent) return;
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

export default app;
