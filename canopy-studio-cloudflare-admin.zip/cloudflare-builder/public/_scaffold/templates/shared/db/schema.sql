-- One deployment per practice. SITE_ID scopes every row so Vercel and Cloudflare
-- can safely share this Neon database and the same practice data.
CREATE TABLE IF NOT EXISTS sites (
  site_id text PRIMARY KEY,
  config jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Fixed blog schema by design: no custom content types or arbitrary blocks.
CREATE TABLE IF NOT EXISTS blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id text NOT NULL REFERENCES sites(site_id) ON DELETE CASCADE,
  title varchar(140) NOT NULL,
  slug varchar(160) NOT NULL,
  excerpt varchar(260) NOT NULL DEFAULT '',
  body text NOT NULL,
  category varchar(60) NOT NULL DEFAULT 'Practice notes',
  status varchar(12) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (site_id, slug)
);
CREATE INDEX IF NOT EXISTS blog_posts_public_idx ON blog_posts(site_id, status, published_at DESC);

-- Fixed gallery schema shared by every generated theme. Images may be HTTPS URLs or site-relative paths.
CREATE TABLE IF NOT EXISTS gallery_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id text NOT NULL REFERENCES sites(site_id) ON DELETE CASCADE,
  title varchar(120) NOT NULL,
  image_url text NOT NULL DEFAULT '',
  alt_text varchar(180) NOT NULL DEFAULT '',
  caption varchar(300) NOT NULL DEFAULT '',
  category varchar(60) NOT NULL DEFAULT 'Practice life',
  status varchar(12) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
  sort_order integer NOT NULL DEFAULT 0 CHECK (sort_order >= 0 AND sort_order <= 9999),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS gallery_items_public_idx ON gallery_items(site_id, status, sort_order, created_at DESC);

CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id text NOT NULL REFERENCES sites(site_id) ON DELETE CASCADE,
  name varchar(100) NOT NULL,
  email varchar(120) NOT NULL,
  phone varchar(30) NOT NULL,
  service varchar(120) NOT NULL,
  appointment_date date NOT NULL,
  appointment_time time NOT NULL,
  context varchar(100) NOT NULL DEFAULT '',
  status varchar(12) NOT NULL DEFAULT 'requested' CHECK (status IN ('requested', 'confirmed', 'cancelled')),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- A requested or confirmed slot can only be taken once per practice.
CREATE UNIQUE INDEX IF NOT EXISTS appointments_slot_idx
  ON appointments(site_id, appointment_date, appointment_time)
  WHERE status <> 'cancelled';
CREATE INDEX IF NOT EXISTS appointments_date_idx ON appointments(site_id, appointment_date, status);
