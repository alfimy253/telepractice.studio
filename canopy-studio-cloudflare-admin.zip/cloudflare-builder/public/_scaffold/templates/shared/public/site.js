(() => {
  const fallback = window.SITE_CONFIG || {};
  let site = { ...fallback, features: { ...(fallback.features || {}) } };
  let csrfToken = '';
  const $ = (id) => document.getElementById(id);
  const text = (id, value) => { const node = $(id); if (node && value != null) node.textContent = value; };
  const setLink = (id, href, label) => { const node = $(id); if (node) { node.href = href; if (label) node.textContent = label; } };
  const verticalDefaults = {
    veterinary: { icon: '✳', subline: 'CARE THAT FEELS PERSONAL', context: 'Pet name (optional)', book: 'Request a visit', journal: 'Notes from our care team' },
    dental: { icon: '✦', subline: 'A BRIGHTER KIND OF CARE', context: 'Reason for your visit (optional)', book: 'Request an appointment', journal: 'Notes for a healthier smile' }
  };
  const isVet = site.specialty !== 'dental';
  const vertical = verticalDefaults[site.specialty] || verticalDefaults.veterinary;
  const isEnabled = (feature) => site.features?.[feature] !== false;
  const timeSlots = ['09:00','09:30','10:00','10:30','11:00','11:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30'];

  function setTheme() {
    const root = document.documentElement;
    if (site.primaryColor) root.style.setProperty('--primary', site.primaryColor);
    if (site.accentColor) root.style.setProperty('--accent', site.accentColor);
    if (site.paperColor) root.style.setProperty('--paper', site.paperColor);
    document.body.classList.toggle('font-sans', site.fontStyle === 'sans');
    document.body.classList.toggle('dental-site', site.specialty === 'dental');
    document.body.classList.remove('theme-canopy','theme-clay','theme-coastal','theme-editorial','theme-neat','theme-launcher','theme-air');
    if (['canopy','clay','coastal','editorial','neat','launcher','air'].includes(site.theme)) document.body.classList.add(`theme-${site.theme}`);
  }
  function applyContent() {
    const title = site.businessName || 'Practice';
    const brand = site.brandName || title;
    const place = site.location || '';
    document.title = title;
    const description = document.querySelector('meta[name="description"]');
    if (description) description.content = `Thoughtful care from ${title}.`;
    text('brandName', brand); text('footerBrandName', brand); text('footerLegalName', title);
    text('brandSubline', vertical.subline); text('footerBrandSubline', vertical.subline);
    text('footerLocation', place); text('footerEmail', site.email); text('footerPhone', site.phone);
    text('yearNow', new Date().getFullYear());
    setLink('footerEmail', `mailto:${site.email}`);
    setLink('footerPhone', `tel:${String(site.phone || '').replace(/[^+\d]/g, '')}`);
    setLink('phoneLink', `tel:${String(site.phone || '').replace(/[^+\d]/g, '')}`, site.phone);
    text('brandSymbol', vertical.icon); text('footerSymbol', vertical.icon); text('labelIcon', vertical.icon);
    text('editorialBrandSymbol', vertical.icon); text('editorialBrandName', brand); text('editorialBrandLocation', place);
    text('editorialSidebarCta', vertical.book);
    text('heroEyebrow', site.heroEyebrow || (isVet ? 'A LITTLE MORE CARE, EVERY DAY' : 'A BRIGHTER KIND OF DENTAL CARE'));
    const headline = String(site.heroHeadline || (isVet ? 'Good care for\ngood companions.' : 'A reason to\nsmile easier.')).split('\n');
    const headlineNode = $('heroHeadline');
    if (headlineNode) {
      headlineNode.replaceChildren(document.createTextNode(headline[0] || title));
      headlineNode.appendChild(document.createElement('br'));
      const em = document.createElement('em'); em.textContent = headline.slice(1).join(' ') || 'good care.';
      headlineNode.appendChild(em);
    }
    text('heroText', site.heroText || 'Thoughtful care, built around the lives you share.');
    const services = Array.isArray(site.services) ? site.services : [];
    document.querySelectorAll('.service-title').forEach((node, index) => { if (services[index]) node.textContent = services[index]; });
    text('contextLabel', vertical.context);
    text('headerCta', vertical.book); text('heroBook', vertical.book); text('bookingSubmit', isVet ? 'Send visit request ↗' : 'Send appointment request ↗');
    if (site.specialty === 'dental') document.querySelector('.form-heading strong').textContent = 'Request an appointment';
    $('journal')?.classList.toggle('hidden', !isEnabled('blog')); $('journalNav')?.classList.toggle('hidden', !isEnabled('blog')); $('editorialJournalNav')?.classList.toggle('hidden', !isEnabled('blog'));
    $('gallery')?.classList.toggle('hidden', !isEnabled('gallery')); $('galleryNav')?.classList.toggle('hidden', !isEnabled('gallery')); $('editorialGalleryNav')?.classList.toggle('hidden', !isEnabled('gallery'));
    $('book')?.classList.toggle('hidden', !isEnabled('scheduling'));
    if (!isEnabled('scheduling')) {
      setLink('headerCta', '#contact', 'Get in touch');
      setLink('heroBook', '#contact', 'Contact our team');
      setLink('articleBook', '#contact', 'Contact our team');
      setLink('editorialSidebarCta', '#contact', 'Contact our team ↗');
    } else {
      setLink('headerCta', '#book', vertical.book);
      setLink('heroBook', '#book', vertical.book);
      setLink('articleBook', '#book', vertical.book);
      setLink('editorialSidebarCta', '#book', `${vertical.book} ↗`);
    }
  }
  function toast(message, error = false) {
    const node = $('siteToast'); if (!node) return;
    node.textContent = message; node.classList.toggle('error', error); node.classList.add('visible');
    window.clearTimeout(toast.timer); toast.timer = window.setTimeout(() => node.classList.remove('visible'), 4400);
  }
  function openArticle(post) {
    text('articleCategory', post.category || 'From our team');
    text('articleTitle', post.title || 'A note from our team');
    text('articleExcerpt', post.excerpt || '');
    const date = post.publishedAt || post.createdAt;
    text('articleMeta', date ? new Date(date).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' }) : 'A note from our team');
    text('articleBody', post.body || post.excerpt || '');
    const modal = $('articleModal'); modal?.classList.add('open'); modal?.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden'; $('articleClose')?.focus();
  }
  function closeArticle() {
    const modal = $('articleModal'); modal?.classList.remove('open'); modal?.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
  function renderPosts(posts) {
    const grid = $('postGrid'); if (!grid) return;
    grid.replaceChildren();
    const safePosts = Array.isArray(posts) ? posts.filter((post) => post && post.title).slice(0, 12) : [];
    if (!safePosts.length) {
      const note = document.createElement('p'); note.className = 'loading-copy'; note.textContent = 'New notes from our care team are coming soon.'; grid.appendChild(note); return;
    }
    safePosts.forEach((post, index) => {
      const card = document.createElement('article'); card.className = 'post-card'; card.setAttribute('role', 'button'); card.setAttribute('tabindex', '0'); card.setAttribute('aria-label', `Read ${post.title}`);
      card.addEventListener('click', () => openArticle(post));
      card.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openArticle(post); } });
      const image = document.createElement('div'); image.className = 'post-image'; image.setAttribute('aria-hidden','true');
      const symbol = document.createElement('span'); symbol.className = 'image-symbol'; symbol.textContent = ['✳','♡','⌁'][index % 3]; image.appendChild(symbol);
      const content = document.createElement('div'); content.className = 'post-card-content';
      const category = document.createElement('span'); category.className = 'post-category'; category.textContent = post.category || 'From our team';
      const title = document.createElement('h3'); title.textContent = post.title;
      const excerpt = document.createElement('p'); excerpt.textContent = post.excerpt || '';
      const date = document.createElement('div'); date.className = 'post-meta';
      const created = post.publishedAt || post.createdAt;
      date.textContent = created ? new Date(created).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'A note from our team';
      content.append(category, title, excerpt, date); card.append(image, content); grid.appendChild(card);
    });
  }
  async function loadPosts() {
    if (!isEnabled('blog')) return;
    const localPosts = site.demoPosts || [];
    try {
      const response = await fetch('/api/posts', { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error('posts unavailable');
      const result = await response.json(); renderPosts(result.posts || []);
    } catch (_) { renderPosts(localPosts); }
  }
  function safeImageUrl(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    try {
      const parsed = new URL(raw, window.location.origin);
      if (parsed.protocol === 'https:' || (parsed.origin === window.location.origin && raw.startsWith('/') && !raw.startsWith('//'))) return parsed.href;
    } catch (_) {}
    return '';
  }
  function renderGallery(items) {
    const grid = $('galleryGrid'); if (!grid) return;
    grid.replaceChildren();
    const safeItems = Array.isArray(items) ? items.filter((item) => item && item.title).slice(0, 24) : [];
    if (!safeItems.length) {
      const note = document.createElement('p'); note.className = 'loading-copy'; note.textContent = 'A few scenes from practice life are on their way.'; grid.appendChild(note); return;
    }
    safeItems.forEach((item, index) => {
      const card = document.createElement('figure'); card.className = `gallery-card gallery-card-${index % 4}`;
      const media = document.createElement('div'); media.className = 'gallery-image';
      const url = safeImageUrl(item.imageUrl);
      if (url) {
        const image = document.createElement('img'); image.src = url; image.alt = String(item.altText || item.title); image.loading = 'lazy'; image.decoding = 'async'; image.referrerPolicy = 'no-referrer'; media.appendChild(image);
      } else {
        media.classList.add('gallery-placeholder'); media.setAttribute('role', 'img'); media.setAttribute('aria-label', String(item.altText || item.title));
        const ornament = document.createElement('span'); ornament.className = 'gallery-ornament'; ornament.setAttribute('aria-hidden', 'true'); ornament.textContent = ['✳','⌂','♡','✦'][index % 4]; media.appendChild(ornament);
      }
      const caption = document.createElement('figcaption');
      const category = document.createElement('span'); category.className = 'gallery-category'; category.textContent = item.category || 'Practice life';
      const title = document.createElement('strong'); title.textContent = item.title;
      const description = document.createElement('p'); description.textContent = item.caption || '';
      caption.append(category, title, description); card.append(media, caption); grid.appendChild(card);
    });
  }
  async function loadGallery() {
    if (!isEnabled('gallery')) return;
    try {
      const response = await fetch('/api/gallery', { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error('gallery unavailable');
      const result = await response.json(); renderGallery(result.items || []);
    } catch (_) { renderGallery(site.demoGallery || []); }
  }
  async function getCsrf() {
    const response = await fetch('/api/csrf', { credentials: 'same-origin' });
    if (!response.ok) throw new Error('Security token could not be created.');
    const data = await response.json(); csrfToken = data.token; return csrfToken;
  }
  function localDateString(date) {
    const year = date.getFullYear(); const month = String(date.getMonth() + 1).padStart(2, '0'); const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  async function loadAvailability() {
    const date = $('appointmentDate')?.value; const select = $('appointmentTime');
    if (!select || !date) return;
    select.disabled = true; select.replaceChildren(new Option('Checking availability…', ''));
    try {
      const response = await fetch(`/api/availability?date=${encodeURIComponent(date)}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error('No appointment times are available yet. Please call the practice.');
      const data = await response.json(); const slots = Array.isArray(data.slots) ? data.slots : [];
      select.replaceChildren(new Option(slots.length ? 'Choose a time' : 'No times available', ''));
      slots.forEach((slot) => select.add(new Option(slot.label || slot.time, slot.time)));
      select.disabled = slots.length === 0;
      if (!slots.length) toast('No times left for that date', 'Choose another day or contact the practice.');
    } catch (error) {
      select.replaceChildren(new Option('Call to request a time', ''));
      select.disabled = true;
      const message = $('bookingMessage'); if (message) { message.textContent = 'Online availability is not connected yet. Please call the practice.'; message.classList.add('error'); }
    }
  }
  async function submitBooking(event) {
    event.preventDefault();
    const form = event.currentTarget; const button = $('bookingSubmit'); const message = $('bookingMessage');
    if (!form.reportValidity()) return;
    const formData = new FormData(form);
    const payload = {
      name: String(formData.get('name') || '').trim(), email: String(formData.get('email') || '').trim(),
      phone: String(formData.get('phone') || '').trim(), service: String(formData.get('service') || '').trim(),
      date: String(formData.get('date') || ''), time: String(formData.get('time') || ''),
      context: String(formData.get('context') || '').trim()
    };
    button.disabled = true; button.textContent = 'Sending request…'; message.textContent = ''; message.classList.remove('error');
    try {
      if (!csrfToken) await getCsrf();
      const response = await fetch('/api/appointments', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken }, body: JSON.stringify(payload) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'We could not send this request. Please call the practice.');
      message.textContent = 'Thank you — your request is in. Our team will follow up to confirm.';
      form.reset(); $('appointmentTime').replaceChildren(new Option('Select a date first', '')); $('appointmentTime').disabled = true;
      toast('Request received', 'The practice will contact you to confirm your appointment.');
    } catch (error) { message.textContent = error.message; message.classList.add('error'); }
    finally { button.disabled = false; button.textContent = isVet ? 'Send visit request ↗' : 'Send appointment request ↗'; }
  }
  function setupBooking() {
    const date = $('appointmentDate'); if (!date || !isEnabled('scheduling')) return;
    date.min = localDateString(new Date());
    date.addEventListener('change', loadAvailability);
    $('bookingForm')?.addEventListener('submit', submitBooking);
    const serviceSelect = $('serviceSelect');
    const services = Array.isArray(site.services) && site.services.length ? site.services : (isVet ? ['Wellness visit','New patient visit','Follow-up'] : ['Preventive care','New patient consultation','Follow-up']);
    services.forEach((service) => serviceSelect.add(new Option(service, service)));
    getCsrf().catch(() => {});
  }
  async function refreshSiteConfig() {
    try {
      const response = await fetch('/api/site', { headers: { Accept: 'application/json' } });
      if (response.ok) {
        const data = await response.json();
        if (data.config && typeof data.config === 'object') { site = { ...site, ...data.config, features: { ...site.features, ...(data.config.features || {}) } }; }
      }
    } catch (_) { /* use the generated config fallback */ }
    setTheme(); applyContent(); setupBooking(); loadPosts(); loadGallery();
  }
  $('articleClose')?.addEventListener('click', closeArticle);
  $('articleModal')?.addEventListener('click', (event) => { if (event.target === $('articleModal')) closeArticle(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && $('articleModal')?.classList.contains('open')) closeArticle(); });
  $('navMenu')?.addEventListener('click', () => $('siteNav')?.classList.toggle('open'));
  document.querySelectorAll('#siteNav a').forEach((link) => link.addEventListener('click', () => $('siteNav')?.classList.remove('open')));
  setTheme(); applyContent();
  refreshSiteConfig();
})();
