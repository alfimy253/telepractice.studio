import { neon } from '@neondatabase/serverless';

const SITE_ID = '__SITE_ID__';
const DEFAULT_CONFIG = __SITE_CONFIG_JSON__;
const SLOT_TIMES = ['09:00','09:30','10:00','10:30','11:00','11:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30'];
const CSRF_COOKIE = 'practice_csrf';
const encoder = new TextEncoder();

function headersWithSecurity(source = {}) {
  const headers = new Headers(source);
  headers.set('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  headers.set('X-Frame-Options', 'DENY');
  headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  headers.set('Cross-Origin-Resource-Policy', 'same-site');
  return headers;
}
function json(data, status = 200, extra = {}) {
  const headers = headersWithSecurity({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra });
  return new Response(JSON.stringify(data), { status, headers });
}
function error(message, status = 400) { return json({ error: message }, status); }
function cleanText(value, max, fallback = '') { return String(value ?? fallback).trim().slice(0, max); }
function validColor(value, fallback) { return /^#[0-9a-f]{6}$/i.test(String(value || '')) ? String(value) : fallback; }
function cleanSiteConfig(input = {}) {
  const merged = { ...DEFAULT_CONFIG, ...input };
  return {
    ...DEFAULT_CONFIG,
    businessName: cleanText(merged.businessName, 80, DEFAULT_CONFIG.businessName),
    brandName: cleanText(merged.brandName, 80, DEFAULT_CONFIG.brandName),
    location: cleanText(merged.location, 100, DEFAULT_CONFIG.location),
    email: cleanText(merged.email, 120, DEFAULT_CONFIG.email),
    phone: cleanText(merged.phone, 30, DEFAULT_CONFIG.phone),
    primaryColor: validColor(merged.primaryColor, DEFAULT_CONFIG.primaryColor),
    accentColor: validColor(merged.accentColor, DEFAULT_CONFIG.accentColor),
    paperColor: validColor(merged.paperColor, DEFAULT_CONFIG.paperColor),
    fontStyle: merged.fontStyle === 'sans' ? 'sans' : 'serif',
    theme: ['canopy','clay','coastal','editorial','neat','launcher','air'].includes(merged.theme) ? merged.theme : DEFAULT_CONFIG.theme,
    editorialAccent: ['black','teal','forest'].includes(merged.editorialAccent) ? merged.editorialAccent : 'black',
    features: { ...DEFAULT_CONFIG.features, ...(merged.features || {}), gallery: merged.features?.gallery !== false }
  };
}
function validDate(value) { return /^\d{4}-\d{2}-\d{2}$/.test(value) && value >= new Date().toISOString().slice(0, 10); }
function slugify(value) { return String(value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 160) || 'practice-note'; }
function cleanGalleryImage(value) {
  const raw = cleanText(value, 2048);
  if (!raw) return '';
  if (raw.startsWith('/') && !raw.startsWith('//')) return raw;
  try { const url = new URL(raw); return url.protocol === 'https:' ? url.href : null; } catch (_) { return null; }
}
function galleryPayload(value = {}) {
  const imageUrl = cleanGalleryImage(value.imageUrl);
  const sortOrder = Number(value.sortOrder ?? 0);
  return {
    title: cleanText(value.title, 120), imageUrl, altText: cleanText(value.altText, 180),
    caption: cleanText(value.caption, 300), category: cleanText(value.category, 60, 'Practice life') || 'Practice life',
    status: value.status === 'published' ? 'published' : 'draft', sortOrder
  };
}
function validGalleryPayload(item) {
  return item.title && item.imageUrl !== null && Number.isInteger(item.sortOrder) && item.sortOrder >= 0 && item.sortOrder <= 9999 && (!item.imageUrl || item.altText);
}
function displayTime(value) {
  const [hour, minute] = value.split(':').map(Number); const suffix = hour >= 12 ? 'pm' : 'am';
  return `${hour % 12 || 12}:${String(minute).padStart(2, '0')} ${suffix}`;
}
function sql(env) {
  if (!env.DATABASE_URL) throw new Error('Database is not configured.');
  return neon(env.DATABASE_URL);
}
function base64url(bytes) {
  let binary = ''; for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
function decodeBase64url(value) {
  const normalized = value.replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - normalized.length % 4) % 4);
  const binary = atob(padded); return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}
async function hmac(value, secret) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(value)));
}
async function issueCsrf(request, env) {
  const secret = env.CSRF_SECRET || env.ADMIN_API_KEY;
  if (!secret) return error('Set a CSRF_SECRET Worker secret before using forms.', 503);
  const nonceBytes = crypto.getRandomValues(new Uint8Array(24));
  const nonce = base64url(nonceBytes);
  const signature = base64url(await hmac(nonce, secret));
  const token = `${nonce}.${signature}`;
  const secure = new URL(request.url).protocol === 'https:' ? '; Secure' : '';
  // Wrangler local may use http; production is always served over HTTPS.
  return json({ token }, 200, { 'Set-Cookie': `${CSRF_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=3600${secure}` });
}
function readCookie(header, name) {
  for (const item of String(header || '').split(';')) {
    const index = item.indexOf('='); if (index < 0) continue;
    if (item.slice(0, index).trim() === name) return decodeURIComponent(item.slice(index + 1).trim());
  }
  return '';
}
function constantEqual(left, right) {
  const a = encoder.encode(String(left || '')); const b = encoder.encode(String(right || ''));
  let diff = a.length ^ b.length; const max = Math.max(a.length, b.length);
  for (let i = 0; i < max; i++) diff |= (a[i % (a.length || 1)] || 0) ^ (b[i % (b.length || 1)] || 0);
  return diff === 0;
}
async function csrfOk(request, env) {
  const url = new URL(request.url);
  const origin = request.headers.get('Origin');
  if (origin && origin !== url.origin) return false;
  const cookie = readCookie(request.headers.get('Cookie'), CSRF_COOKIE);
  const header = request.headers.get('X-CSRF-Token');
  if (!cookie || !header || !constantEqual(cookie, header)) return false;
  const secret = env.CSRF_SECRET || env.ADMIN_API_KEY;
  if (!secret) return false;
  const [nonce, signature, ...rest] = header.split('.');
  if (!nonce || !signature || rest.length) return false;
  let actual; try { actual = decodeBase64url(signature); } catch (_) { return false; }
  const expected = await hmac(nonce, secret);
  return actual.length === expected.length && constantEqual(base64url(actual), base64url(expected));
}
function adminOk(request, env) {
  const expected = env.ADMIN_API_KEY || '';
  const authorization = request.headers.get('Authorization') || '';
  const given = authorization.replace(/^Bearer\s+/i, '');
  return Boolean(expected && given && constantEqual(expected, given));
}
function adminFailure(env) { return env.ADMIN_API_KEY ? error('Owner key is not valid.', 401) : error('Owner access has not been configured. Set the ADMIN_API_KEY Worker secret.', 503); }
async function readJson(request) {
  try { return await request.json(); } catch (_) { return null; }
}
async function siteConfig(env) {
  if (!env.DATABASE_URL) return { config: DEFAULT_CONFIG, source: 'generated-fallback' };
  try {
    const rows = await sql(env)`SELECT config FROM sites WHERE site_id = ${SITE_ID} LIMIT 1`;
    return { config: rows[0]?.config || DEFAULT_CONFIG, source: rows[0] ? 'neon' : 'generated-fallback' };
  } catch (cause) { console.error('site config read failed', cause); return { config: DEFAULT_CONFIG, source: 'generated-fallback' }; }
}
async function routeApi(request, env) {
  const url = new URL(request.url); const path = url.pathname; const method = request.method.toUpperCase();
  if (path === '/api/health' && method === 'GET') return json({ ok: true, runtime: 'cloudflare-workers', siteId: SITE_ID });
  if (path === '/api/csrf' && method === 'GET') return issueCsrf(request, env);
  if (path === '/api/site' && method === 'GET') return json(await siteConfig(env));
  if (path === '/api/site' && method === 'PUT') {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!adminOk(request, env)) return adminFailure(env);
    const body = await readJson(request); if (!body) return error('Send a valid JSON object.');
    const config = cleanSiteConfig(body);
    if (!config.businessName || (config.email && !/^\S+@\S+\.\S+$/.test(config.email))) return error('Check the practice name and contact email.');
    try {
      const rows = await sql(env)`INSERT INTO sites (site_id, config) VALUES (${SITE_ID}, ${JSON.stringify(config)}::jsonb) ON CONFLICT (site_id) DO UPDATE SET config = EXCLUDED.config, updated_at = now() RETURNING config`;
      return json({ config: rows[0].config });
    } catch (cause) { console.error('site config save failed', cause); return error('Could not save the site settings. Check the Neon schema and connection.', 503); }
  }
  if (path === '/api/posts' && method === 'GET') {
    if (!DEFAULT_CONFIG.features?.blog) return json({ posts: [] });
    if (!env.DATABASE_URL) return json({ posts: DEFAULT_CONFIG.demoPosts || [] });
    try {
      const posts = await sql(env)`SELECT id, title, slug, excerpt, body, category, published_at AS "publishedAt", created_at AS "createdAt" FROM blog_posts WHERE site_id = ${SITE_ID} AND status = 'published' ORDER BY published_at DESC NULLS LAST, created_at DESC LIMIT 12`;
      return json({ posts });
    } catch (cause) { console.error('blog read failed', cause); return error('Could not load journal posts.', 503); }
  }
  if (path === '/api/gallery' && method === 'GET') {
    if (!DEFAULT_CONFIG.features?.gallery) return json({ items: [] });
    if (!env.DATABASE_URL) return json({ items: DEFAULT_CONFIG.demoGallery || [] });
    try {
      const items = await sql(env)`SELECT id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt" FROM gallery_items WHERE site_id = ${SITE_ID} AND status = 'published' ORDER BY sort_order ASC, created_at DESC LIMIT 24`;
      return json({ items });
    } catch (cause) { console.error('gallery read failed', cause); return error('Could not load gallery items.', 503); }
  }
  if (path === '/api/availability' && method === 'GET') {
    const date = String(url.searchParams.get('date') || '');
    if (!validDate(date)) return error('Choose a valid future date.');
    if (new Date(`${date}T00:00:00Z`).getUTCDay() === 0) return json({ slots: [] });
    if (!env.DATABASE_URL) return error('Appointment database is not configured.', 503);
    try {
      const rows = await sql(env)`SELECT to_char(appointment_time, 'HH24:MI') AS time FROM appointments WHERE site_id = ${SITE_ID} AND appointment_date = ${date}::date AND status <> 'cancelled'`;
      const taken = new Set(rows.map((row) => row.time));
      return json({ slots: SLOT_TIMES.filter((time) => !taken.has(time)).map((time) => ({ time, label: displayTime(time) })) });
    } catch (cause) { console.error('availability read failed', cause); return error('Could not load available times.', 503); }
  }
  if (path === '/api/appointments' && method === 'POST') {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!DEFAULT_CONFIG.features?.scheduling) return error('Online appointment requests are not enabled.', 404);
    const value = await readJson(request); if (!value) return error('Send a valid JSON object.');
    const booking = { name: cleanText(value.name, 100), email: cleanText(value.email, 120), phone: cleanText(value.phone, 30), service: cleanText(value.service, 120), date: String(value.date || ''), time: String(value.time || ''), context: cleanText(value.context, 100) };
    if (!booking.name || !/^\S+@\S+\.\S+$/.test(booking.email) || !booking.phone || !DEFAULT_CONFIG.services.includes(booking.service) || !validDate(booking.date) || !SLOT_TIMES.includes(booking.time)) return error('Check the required appointment details and choose a valid time.');
    try {
      const rows = await sql(env)`INSERT INTO appointments (site_id, name, email, phone, service, appointment_date, appointment_time, context) VALUES (${SITE_ID}, ${booking.name}, ${booking.email}, ${booking.phone}, ${booking.service}, ${booking.date}::date, ${booking.time}::time, ${booking.context}) RETURNING id`;
      return json({ ok: true, id: rows[0]?.id }, 201);
    } catch (cause) {
      if (cause.code === '23505') return error('That time was just taken. Please choose another available time.', 409);
      console.error('appointment request failed', cause); return error('We could not save your request. Please call the practice.', 503);
    }
  }
  if (path === '/api/admin/appointments' && method === 'GET') {
    if (!adminOk(request, env)) return adminFailure(env);
    try {
      const appointments = await sql(env)`SELECT id, name, email, phone, service, context, status, appointment_date::text AS date, to_char(appointment_time, 'HH24:MI') AS time FROM appointments WHERE site_id = ${SITE_ID} AND appointment_date >= current_date AND appointment_date <= current_date + interval '90 days' ORDER BY appointment_date ASC, appointment_time ASC LIMIT 200`;
      return json({ appointments: appointments.map((row) => ({ ...row, timeLabel: displayTime(row.time) })) });
    } catch (cause) { console.error('appointment list failed', cause); return error('Could not load appointment requests. Check the Neon schema.', 503); }
  }
  if (path.startsWith('/api/admin/appointments/') && method === 'PATCH') {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!adminOk(request, env)) return adminFailure(env);
    const id = path.slice('/api/admin/appointments/'.length);
    const value = await readJson(request);
    const status = String(value?.status || '');
    if (!/^[0-9a-f-]{36}$/i.test(id) || !['requested', 'confirmed', 'cancelled'].includes(status)) return error('Invalid appointment update.');
    try {
      const rows = await sql(env)`UPDATE appointments SET status = ${status} WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id, status`;
      return rows.length ? json({ appointment: rows[0] }) : error('That appointment was not found.', 404);
    } catch (cause) {
      if (cause.code === '23505') return error('That time slot has already been taken.', 409);
      console.error('appointment update failed', cause); return error('Could not update the appointment.', 503);
    }
  }
  if (path === '/api/admin/posts' && method === 'GET') {
    if (!adminOk(request, env)) return adminFailure(env);
    try {
      const posts = await sql(env)`SELECT id, title, slug, excerpt, body, category, status, published_at AS "publishedAt", created_at AS "createdAt" FROM blog_posts WHERE site_id = ${SITE_ID} ORDER BY created_at DESC LIMIT 100`;
      return json({ posts });
    } catch (cause) { console.error('admin blog read failed', cause); return error('Could not load blog posts. Check the Neon schema.', 503); }
  }
  if (path === '/api/admin/posts' && method === 'POST') {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!adminOk(request, env)) return adminFailure(env);
    const value = await readJson(request); if (!value) return error('Send a valid JSON object.');
    const title = cleanText(value.title, 140); const slug = slugify(value.slug || title); const excerpt = cleanText(value.excerpt, 260); const body = cleanText(value.body, 12000); const category = cleanText(value.category, 60, 'Practice notes') || 'Practice notes'; const status = value.status === 'published' ? 'published' : 'draft';
    if (!title || !body) return error('A title and article body are required.');
    try {
      const posts = await sql(env)`INSERT INTO blog_posts (site_id, title, slug, excerpt, body, category, status, published_at) VALUES (${SITE_ID}, ${title}, ${slug}, ${excerpt}, ${body}, ${category}, ${status}, CASE WHEN ${status} = 'published' THEN now() ELSE NULL END) RETURNING id, title, slug, excerpt, category, status, created_at AS "createdAt"`;
      return json({ post: posts[0] }, 201);
    } catch (cause) { console.error('blog post save failed', cause); return error(cause.code === '23505' ? 'That URL slug is already in use.' : 'Could not save the post.', cause.code === '23505' ? 409 : 503); }
  }
  if (path.startsWith('/api/admin/posts/') && method === 'PUT') {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!adminOk(request, env)) return adminFailure(env);
    const id = path.slice('/api/admin/posts/'.length);
    const value = await readJson(request); if (!value) return error('Send a valid JSON object.');
    if (!/^[0-9a-f-]{36}$/i.test(id)) return error('Invalid post id.');
    const title = cleanText(value.title, 140); const slug = slugify(value.slug || title); const excerpt = cleanText(value.excerpt, 260); const body = cleanText(value.body, 12000); const category = cleanText(value.category, 60, 'Practice notes') || 'Practice notes'; const status = value.status === 'published' ? 'published' : 'draft';
    if (!title || !body) return error('A title and article body are required.');
    try {
      const posts = await sql(env)`UPDATE blog_posts SET title = ${title}, slug = ${slug}, excerpt = ${excerpt}, body = ${body}, category = ${category}, status = ${status}, published_at = CASE WHEN ${status} = 'published' THEN COALESCE(published_at, now()) ELSE NULL END, updated_at = now() WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id, title, slug, excerpt, body, category, status, published_at AS "publishedAt"`;
      return posts.length ? json({ post: posts[0] }) : error('That post was not found.', 404);
    } catch (cause) {
      if (cause.code === '23505') return error('That URL slug is already in use.', 409);
      console.error('blog post update failed', cause); return error('Could not update the post.', 503);
    }
  }
  if (path.startsWith('/api/admin/posts/') && method === 'DELETE') {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!adminOk(request, env)) return adminFailure(env);
    const id = path.slice('/api/admin/posts/'.length);
    if (!/^[0-9a-f-]{36}$/i.test(id)) return error('Invalid post id.');
    try {
      const rows = await sql(env)`DELETE FROM blog_posts WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id`;
      return rows.length ? json({ ok: true }) : error('That post was not found.', 404);
    } catch (cause) { console.error('blog post delete failed', cause); return error('Could not delete the post.', 503); }
  }
  if (path === '/api/admin/gallery' && method === 'GET') {
    if (!adminOk(request, env)) return adminFailure(env);
    try {
      const items = await sql(env)`SELECT id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt" FROM gallery_items WHERE site_id = ${SITE_ID} ORDER BY sort_order ASC, created_at DESC LIMIT 100`;
      return json({ items });
    } catch (cause) { console.error('gallery admin read failed', cause); return error('Could not load gallery items. Check the Neon schema.', 503); }
  }
  if (path === '/api/admin/gallery' && method === 'POST') {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!adminOk(request, env)) return adminFailure(env);
    const value = await readJson(request); if (!value) return error('Send a valid JSON object.');
    const item = galleryPayload(value);
    if (!validGalleryPayload(item)) return error('Add a title, valid HTTPS or same-site image URL and alternative text. Display order must be from 0 to 9999.');
    try {
      const items = await sql(env)`INSERT INTO gallery_items (site_id, title, image_url, alt_text, caption, category, status, sort_order) VALUES (${SITE_ID}, ${item.title}, ${item.imageUrl}, ${item.altText}, ${item.caption}, ${item.category}, ${item.status}, ${item.sortOrder}) RETURNING id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt"`;
      return json({ item: items[0] }, 201);
    } catch (cause) { console.error('gallery item create failed', cause); return error('Could not save the gallery item.', 503); }
  }
  if (path.startsWith('/api/admin/gallery/') && (method === 'PUT' || method === 'DELETE')) {
    if (!await csrfOk(request, env)) return error('Cross-site request rejected or security token expired.', 403);
    if (!adminOk(request, env)) return adminFailure(env);
    const id = path.slice('/api/admin/gallery/'.length);
    if (!/^[0-9a-f-]{36}$/i.test(id)) return error('Invalid gallery item id.');
    if (method === 'DELETE') {
      try {
        const rows = await sql(env)`DELETE FROM gallery_items WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id`;
        return rows.length ? json({ ok: true }) : error('That gallery item was not found.', 404);
      } catch (cause) { console.error('gallery item delete failed', cause); return error('Could not delete the gallery item.', 503); }
    }
    const value = await readJson(request); if (!value) return error('Send a valid JSON object.');
    const item = galleryPayload(value);
    if (!validGalleryPayload(item)) return error('Add a title, valid HTTPS or same-site image URL and alternative text. Display order must be from 0 to 9999.');
    try {
      const items = await sql(env)`UPDATE gallery_items SET title = ${item.title}, image_url = ${item.imageUrl}, alt_text = ${item.altText}, caption = ${item.caption}, category = ${item.category}, status = ${item.status}, sort_order = ${item.sortOrder}, updated_at = now() WHERE site_id = ${SITE_ID} AND id = ${id}::uuid RETURNING id, title, image_url AS "imageUrl", alt_text AS "altText", caption, category, status, sort_order AS "sortOrder", created_at AS "createdAt"`;
      return items.length ? json({ item: items[0] }) : error('That gallery item was not found.', 404);
    } catch (cause) { console.error('gallery item update failed', cause); return error('Could not update the gallery item.', 503); }
  }
  return error('API route not found.', 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) {
      try { return await routeApi(request, env); }
      catch (cause) { console.error('unhandled Worker API error', cause); return error('Something went wrong. Please try again.', 500); }
    }
    if (request.method !== 'GET' && request.method !== 'HEAD') return error('Method not allowed.', 405);
    const response = await env.ASSETS.fetch(request);
    const headers = headersWithSecurity(response.headers);
    if (url.pathname === '/' || url.pathname.endsWith('.html')) headers.set('Cache-Control', 'no-store');
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  }
};
